-- This script is for adding new columns to existing tables.
-- It should be run after initial schema creation and before application deployment
-- if new features require additional data fields.

-- Example: Adding a 'last_login_at' column to a 'users' table
-- ALTER TABLE users
-- ADD COLUMN last_login_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

-- Example: Adding a 'status' column to a 'projects' table
-- ALTER TABLE projects
-- ADD COLUMN status VARCHAR(50) DEFAULT 'active';

-- Example: Adding a 'description' column to a 'services' table
-- ALTER TABLE services
-- ADD COLUMN description TEXT;

-- Always ensure to check if the column already exists before adding to prevent errors
-- Example with IF NOT EXISTS (syntax varies by database, e.g., PostgreSQL, MySQL)
-- ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

-- For MySQL:
-- ALTER TABLE users ADD COLUMN last_login_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
-- ALTER TABLE users ADD COLUMN status VARCHAR(50) DEFAULT 'active';

-- For PostgreSQL:
-- ALTER TABLE users ADD COLUMN last_login_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
-- ALTER TABLE users ADD COLUMN status VARCHAR(50) DEFAULT 'active';

-- Add any other missing columns as identified during development or feature implementation.
-- Remember to update your ORM/database access layer to reflect these schema changes.
